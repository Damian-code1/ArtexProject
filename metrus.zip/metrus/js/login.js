$(document).ready(function() {
    $('#loginForm').submit(function(e) {
        e.preventDefault();

        const ci = $('#ci').val();
        const password = $('#password').val();

        if (ci.length !== 8) {
            showTooltip($('#ci'), 'El CI debe tener exactamente 8 caracteres.');
            return;
        }

        if (password.length <= 4) {
            showTooltip($('#password'), 'La contraseña debe tener más de 4 caracteres.');
            return;
        }

        $.ajax({
            url: 'login_handler.php',
            type: 'POST',
            data: { ci: ci, password: password },
            success: function(response) {
                console.log('Response:', response); // Ver la respuesta del servidor
                if (response.success) {
                    window.location.href = 'rol.php';
                } else {
                    showTooltip($('#loginForm'), response.message || 'Usuario o contraseña incorrectos.');
                }
            },
            error: function(xhr, status, error) {
                console.log('Error:', xhr.responseText); // Ver el error del servidor
                console.log('Status:', status); // Ver el estado de la solicitud
                console.log('Error:', error); // Ver el mensaje de error
                showTooltip($('#loginForm'), 'Ocurrió un error al iniciar sesión.');
            }
        });
    });
});