<?php
header('Content-Type: application/json');
require_once 'conexion.php';

$ci = $_POST['ci'];
$password = $_POST['password'];

$conexion = Conectar::conexion();

$sql = "SELECT * FROM Personas WHERE ci = ? AND contraseña = ?";
$stmt = $conexion->prepare($sql);
if ($stmt === false) {
    echo json_encode(['success' => false, 'message' => 'Error en la preparación de la consulta.']);
    exit();
}
$stmt->bind_param("ss", $ci, $password);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Credenciales inválidas.']);
}

$stmt->close();
$conexion->close();
?>