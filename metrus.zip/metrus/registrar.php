<?php
// Conexión a la base de datos
$servername = "192.168.21.250";
$username = "artex";
$password = "1234";
$dbname = "metrus";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener datos del formulario
$ci = $_POST['ci'];
$mail = $_POST['mail'];
$password = $_POST['password'];

// Validar que los campos no estén vacíos
if (empty($ci) || empty($mail) || empty($password)) {
    die(json_encode(["status" => "error", "message" => "Todos los campos son obligatorios."]));
}

// Verificar si los datos ya existen
$sql_check = "SELECT * FROM Personas WHERE ci='$ci' OR mail='$mail'";
$result = $conn->query($sql_check);

if ($result->num_rows > 0) {
    echo json_encode(["status" => "error", "message" => "El usuario ya existe."]);
} else {
    // Insertar datos en la tabla Personas
    $sql_insert = "INSERT INTO Personas (ci, mail, contraseña) VALUES ('$ci', '$mail', '$password')";

    if ($conn->query($sql_insert) === TRUE) {
        echo json_encode(["status" => "success", "message" => "Registro exitoso"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Error: " . $sql_insert . "<br>" . $conn->error]);
    }
}

// Cerrar conexión
$conn->close();
?>