<?php
class Conectar {
    public static function conexion() {
        $conexion = new mysqli("192.168.21.250", "artex", "1234", "metrus");
        if ($conexion->connect_error) {
            die("Connection failed: " . $conexion->connect_error);
        }
        $conexion->query("SET NAMES 'utf8'");
        return $conexion;
    }
}
?>