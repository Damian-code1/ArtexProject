<?php
// Conexión a la base de datos
$servername = "192.168.21.250";
$username = "artex";
$password = "1234";
$dbname = "metrus";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Conexión fallida: " . $conn->connect_error]);
    exit();
}

// Obtener el código de administrador del formulario
if (isset($_POST['cod_admin'])) {
    $cod_admin = $_POST['cod_admin'];

    // Verificar si el código de administrador existe
    $sql_check = "SELECT * FROM Admins WHERE cod_admin='$cod_admin'";
    $result = $conn->query($sql_check);

    if ($result->num_rows > 0) {
        echo json_encode(["status" => "success", "message" => "Código de administrador verificado."]);
    } else {
        echo json_encode(["status" => "error", "message" => "Código de administrador incorrecto."]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "No se recibió el código de administrador."]);
}

// Cerrar conexión
$conn->close();
?>