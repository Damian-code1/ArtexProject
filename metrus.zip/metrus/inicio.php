<!DOCTYPE html>

<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Metrus</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../Metrus/css/style.css">
</head>

<body>
    <script src="../Metrus/js/script.js" async defer></script>

    <a href="login.php">
        <h2 class="formato-L centrar-iniciar">Iniciar Sesión</h2>
    </a>

    <img src="../Metrus/img/Metrus.png" alt="Logo Metrus" class="logo">
    <img src="../Metrus/img/lineas.png" alt="Decoracion" class="lineas">

</body>

</html>