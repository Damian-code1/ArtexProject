<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Metrus</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php
    require_once 'conexion.php';
    ?>    
    <img src="img/perfil-violeta.png" alt="Perfil" class="perfil-v">  
    <img src="img/Metrus.png" alt="Perfil" class="logoC">  
    <img src="img/lineas.png" alt="Decoracion" class="lineas">
    
    <h1 class="ins">Iniciar Sesión</h1>
    <form id="loginForm" method="post">
        <input type="text" id="ci" class="input-text username" placeholder="Usuario">
        <input type="password" id="password" class="input-password password" placeholder="Contraseña">
        <button type="submit" class="formato-L">Entrar</button>
    </form>

    <script src="js/jquery-3.7.1.min.js"></script>
    <script src="js/functions.js"></script>
    <script src="js/login.js"></script>
</body>
</html>