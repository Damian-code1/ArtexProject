<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrarse - Metrus</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        /* Estilos para el popup */
        .modal {
            display: none; 
            position: fixed; 
            z-index: 1; 
            left: 0;
            top: 0;
            width: 100%; 
            height: 100%; 
            overflow: auto; 
            background-color: rgb(0,0,0); 
            background-color: rgba(0,0,0,0.4); 
            padding-top: 60px; 
        }

        .modal-content {
            background-color: #fefefe;
            margin: 5% auto; 
            padding: 20px;
            border: 1px solid #888;
            width: 80%; 
            max-width: 500px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <img src="img/perfil-violeta.png" alt="Perfil" class="perfil-v">  
    <img src="img/Metrus.png" alt="Perfil" class="logoC">  
    <img src="img/lineas.png" alt="Decoracion" class="lineas">
    
    <h1 class="preg">Registrarse</h1>

    <form id="registerForm" action="registrar.php" method="post">
        <input type="text" id="ci" name="ci" class="R1 formato-form" placeholder="C.I" required>
        <input type="email" id="mail" name="mail" class="R2 formato-form" placeholder="Mail" required>
        <input type="password" id="password" name="password" class="R3 formato-form" placeholder="Contraseña" required>
        <button type="submit" class="formato-L rg-log">Registrar</button>
    </form>

    <!-- Modal -->
    <div id="myModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <p id="modalMessage"></p>
        </div>
    </div>

    <script>
        function showTooltip(element, message) {
            const tooltip = document.createElement('div');
            tooltip.className = 'tooltip';
            tooltip.textContent = message;
            document.body.appendChild(tooltip);

            const rect = element.getBoundingClientRect();
            tooltip.style.left = `${rect.left + window.scrollX}px`;
            tooltip.style.top = `${rect.bottom + window.scrollY}px`;

            setTimeout(() => {
                tooltip.remove();
            }, 3000);
        }

        function showModal(message) {
            $('#modalMessage').text(message);
            $('#myModal').css('display', 'block');
        }

        $(document).ready(function() {
            $('.close').click(function() {
                $('#myModal').css('display', 'none');
            });

            $(window).click(function(event) {
                if (event.target.id === 'myModal') {
                    $('#myModal').css('display', 'none');
                }
            });

            $('#registerForm').submit(function(event) {
                event.preventDefault(); // Evitar el envío del formulario

                const ci = $('#ci');
                const password = $('#password');
                let valid = true;

                if (ci.val().length !== 8) {
                    showTooltip(ci[0], 'La C.I debe tener 8 caracteres.');
                    valid = false;
                }

                if (password.val().length <= 4) {
                    showTooltip(password[0], 'La contraseña debe tener más de 4 caracteres.');
                    valid = false;
                }

                if (valid) {
                    $.ajax({
                        url: 'registrar.php',
                        type: 'POST',
                        data: $('#registerForm').serialize(),
                        dataType: 'json',
                        success: function(response) {
                            if (response.status === 'error') {
                                showModal(response.message);
                                $('#registerForm')[0].reset();
                            } else {
                                showModal(response.message);
                            }
                        },
                        error: function() {
                            showModal('Error en la solicitud.');
                        }
                    });
                }
            });
        });
    </script>
</body>
</html>