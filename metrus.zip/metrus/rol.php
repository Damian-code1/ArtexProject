<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seleccionar Rol - Metrus</title>
    <style>
        /* Estilos generales */
        body {
            font-family: Arial, sans-serif;
            background-color: #3C145B;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            height: 100vh;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #6A329F;
            padding: 10px;
            width: 100%;
            position: fixed;
            top: 0;
        }

        .menu-icon,
        .user-icon {
            font-size: 30px;
            color: white;
        }

        .logoo h1 {
            margin: 0;
            font-size: 24px;
            font-weight: bold;
            color: white;
        }

        .logoo h1 a {
            color: white;
            text-decoration: none;
        }

        main {
            margin-top: 70px;
            text-align: center;
            width: 100%;
        }

        h2 {
            font-size: 28px;
            margin-bottom: 40px;
            text-decoration: underline;
            color: white;
        }

        .roles-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: calc(100vh - 150px);
        }

        .roles {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
            padding: 20px;
        }

        .role {
            background-color: #6A329F;
            color: white;
            padding: 30px;
            border-radius: 10px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            width: 250px;
            text-align: center;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            cursor: pointer;
            border: none;
        }

        .role:hover {
            transform: scale(1.05);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }

        .role img {
            width: 80px;
            height: 80px;
            margin-bottom: 15px;
            border-radius: 50%;
            border: 2px solid white;
        }

        .role h4 {
            margin: 0;
            font-size: 22px;
            margin-bottom: 10px;
            font-weight: bold;
        }

        /* Estilos para el modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.5);
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background-color: #5C2A82;
            padding: 20px;
            border-radius: 10px;
            width: 300px;
            text-align: center;
            color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            position: relative;
            animation: fadeIn 0.5s;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .modal-content input {
            width: 100%;
            padding: 10px;
            margin: 15px 0;
            border-radius: 5px;
            border: 1px solid #ddd;
            background-color: #4B2B6F;
            color: white;
            font-size: 16px;
        }

        .modal-content button {
            background-color: #7D3DCF;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .modal-content button:hover {
            background-color: #9C4FE5;
        }

        .close {
            position: absolute;
            top: 10px;
            right: 20px;
            font-size: 25px;
            cursor: pointer;
            color: white;
        }

        .close:hover,
        .close:focus {
            color: #ccc;
            text-decoration: none;
            cursor: pointer;
        }

        .itxc {
            text-align: center;
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <header>
        <div class="menu-icon">
            <span style="cursor: pointer;">&#9776;</span>
        </div>
        <div class="logoo">
            <h1><a href="inicio.php">metrus.</a></h1>
        </div>
        <div class="user-icon">
            <span style="cursor: pointer;">&#128100;</span>
        </div>
    </header>
    <main>
        <h2 class="posrol">¿Cuál es su Rol?</h2>
        <div class="roles-container">
            <div class="roles">
                <button class="role" id="adminButton">
                    <img src="img/lapiz.png" alt="Administrador Icon"> <br>
                    <h4>Administrador</h4>
                </button>
                <button class="role">
                    <img src="img/docente.png" alt="Docente Icon"> <br>
                    <h4>Docente</h4>
                </button>
            </div>
        </div>
    </main>

    <!-- Modal -->
    <div id="miModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <p id="mensajeModal"></p>
            <form id="codigoAdminForm" class="itxc">
                <label for="cod_admin">Código de Administrador:</label>
                <input type="text" id="cod_admin" name="cod_admin" required>
                <button type="submit">Verificar</button>
            </form>
        </div>
    </div>

    <script>
        function mostrarModal(mensaje) {
            $('#mensajeModal').text(mensaje);
            $('#miModal').css('display', 'flex');
        }

        $(document).ready(function() {
            // Asegúrate de que el modal esté oculto al cargar la página
            $('#miModal').css('display', 'none');

            $('.close').click(function() {
                $('#miModal').css('display', 'none');
            });
            
            $(window).click(function(evento) {
                if (evento.target.id === 'miModal') {
                    $('#miModal').css('display', 'none');
                }
            });

            $('#adminButton').click(function() {
                $('#miModal').css('display', 'flex');
            });

            $('#codigoAdminForm').submit(function(evento) {
                evento.preventDefault(); // Evitar el envío del formulario

                const cod_admin = $('#cod_admin').val();

                $.ajax({
                    url: 'verificar.php',
                    type: 'POST',
                    data: { cod_admin: cod_admin },
                    dataType: 'json',
                    success: function(respuesta) {
                        if (respuesta.status === 'error') {
                            mostrarModal(respuesta.message);
                        } else {
                            mostrarModal(respuesta.message);
                            // Redirigir a la página de administrador si el código es correcto
                            window.location.href = 'calendario.php';
                        }
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        mostrarModal('Error en la solicitud: ' + textStatus + ' - ' + errorThrown);
                    }
                });
            });
        });
    </script>
</body>
</html>