<?php
session_start();
header('Content-Type: application/json');
require_once 'conexion.php';

$ci = $_POST['ci'];
$password = $_POST['password'];

$conexion = Conectar::conexion();

$sql = "SELECT ci, mail, contraseña, nombre FROM Personas WHERE ci = ? AND contraseña = ?";
$stmt = $conexion->prepare($sql);
if ($stmt === false) {
    echo json_encode(['success' => false, 'message' => 'Error en la preparación de la consulta.']);
    exit();
}
$stmt->bind_param("ss", $ci, $password);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    $_SESSION['user'] = [
        'ci' => $user['ci'],
        'mail' => $user['mail'],
        'nombre' => $user['nombre'],
        'password' => $user['contraseña']
    ];
    echo json_encode(['success' => true, 'message' => 'Inicio de sesión exitoso.']);
} else {
    echo json_encode(['success' => false, 'message' => 'Credenciales inválidas.']);
}

$stmt->close();
$conexion->close();
?>