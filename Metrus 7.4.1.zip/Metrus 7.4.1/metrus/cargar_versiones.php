<?php
require 'conexion.php';

header('Content-Type: application/json');

$result = $conn->query("SELECT DISTINCT version FROM Asignaturas");
$versiones = [];
while ($row = $result->fetch_assoc()) {
    $versiones[] = $row;
}

echo json_encode($versiones);

$conn->close();
?>