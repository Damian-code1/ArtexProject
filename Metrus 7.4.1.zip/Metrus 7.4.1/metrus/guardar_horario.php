<?php
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dia = $_POST['dia'];
    $hora = $_POST['hora'];
    $curso = $_POST['curso'];
    $color = $_POST['color'];
    $grado = $_POST['grado'];
    $año_D = $_POST['año_D'];
    $ci_D = $_POST['ci_D'];
    $nombre_A = $_POST['nombre_A'];
    $nombre_G = $_POST['nombre_G'];
    $id_G = $_POST['id_G'];

    $conn = new mysqli('localhost', 'root', '', 'metrus');
    if ($conn->connect_error) {
        die("Conexión fallida: {$conn->connect_error}");
    }

    $stmt = $conn->prepare("INSERT INTO Pertenece (dia_H, hora_H, año_D, ci_D, nombre_A, nombre_G, id_G) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param('sissssi', $dia, $hora, $año_D, $ci_D, $nombre_A, $nombre_G, $id_G);

    if ($stmt->execute()) {
        echo "Horario guardado correctamente.";
    } else {
        echo "Error al guardar el horario: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>