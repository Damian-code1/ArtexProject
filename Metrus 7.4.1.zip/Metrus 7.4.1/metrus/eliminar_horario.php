<?php
require 'conexion.php';

$dia = $_POST['dia'];
$hora = $_POST['hora'];

$stmt = $conn->prepare("DELETE FROM HorariosGrados WHERE dia = ? AND hora = ?");
$stmt->bind_param('ss', $dia, $hora);

if ($stmt->execute()) {
    echo "Horario eliminado correctamente.";
} else {
    echo "Error al eliminar el horario: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>