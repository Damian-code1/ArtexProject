<?php
require 'conexion.php';

header('Content-Type: application/json');

$cod_docente = $_POST['cod_docente'];

$stmt = $conn->prepare("SELECT dia, hora, curso, color FROM HorariosDocentes WHERE ci_D = (SELECT ci_P FROM Docentes WHERE cod_docente = ?)");
$stmt->bind_param('s', $cod_docente);
$stmt->execute();
$result = $stmt->get_result();

$horarios = [];
while ($row = $result->fetch_assoc()) {
    $horarios[] = $row;
}

if (count($horarios) > 0) {
    echo json_encode(['status' => 'success', 'horarios' => $horarios]);
} else {
    echo json_encode(['status' => 'error', 'message' => 'No se encontraron horarios para el código de docente proporcionado.']);
}

$stmt->close();
$conn->close();
?>