<?php
require_once 'conexion.php';

header('Content-Type: application/json');

$conn = Conectar::conexion();

if (isset($_POST['cod_admin'])) {
    $cod_admin = $conn->real_escape_string($_POST['cod_admin']);

    $sql_check = "SELECT * FROM Admins WHERE cod_admin='$cod_admin'";
    $result = $conn->query($sql_check);

    if ($result->num_rows > 0) {
        echo json_encode(["status" => "success", "message" => "Código de administrador verificado."]);
    } else {
        echo json_encode(["status" => "error", "message" => "Código de administrador incorrecto."]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "No se recibió el código de administrador."]);
}

$conn->close();
?>