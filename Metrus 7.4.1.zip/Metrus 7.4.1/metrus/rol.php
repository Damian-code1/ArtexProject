<?php
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit();
}
$user = $_SESSION['user'];
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seleccionar Rol - Metrus</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="css/rol.css">
    <style>
    header {
        display: flex;
        justify-content: center;
        align-items: center;
        background-color: #6A329F;
        padding: 10px;
        width: 100%;
        position: fixed;
        top: 0;
        z-index: 1000;
    }

    .menu-icon {
        font-size: 30px;
        color: white;
        cursor: pointer;
        position: absolute;
        left: 10px;
    }

    .logoo h1 {
        margin: 0;
        font-size: 24px;
        font-weight: bold;
        color: white;
    }

    .logoo h1 a {
        color: white;
        text-decoration: none;
    }
    </style>
</head>

<body>
    <header>
        <span class="menu-icon" onclick="openNav()"><i class="fas fa-bars"></i></span>
        <div class="logoo">
            <h1><a href="inicio.php">metrus.</a></h1>
        </div>
    </header>

    <div id="mySidebar" class="sidebar">
        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
        <div class="user-info">
            <?php echo htmlspecialchars($user['nombre']); ?>
        </div>
        <button class="logout-btn" onclick="logout()">Cerrar Sesión</button>
    </div>

    <main>
        <div class="roles-container">
            <div class="roles">
                <button class="role" id="adminButton">
                    <img src="img/lapiz.png" alt="Administrador Icon"> <br>
                    <h4>Administrador</h4>
                </button>
                <button class="role" id="docenteButton">
                    <img src="img/docente.png" alt="Docente Icon"> <br>
                    <h4>Docente</h4>
                </button>
            </div>
        </div>
    </main>

    <div id="miModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <p id="mensajeModal"></p>
            <form id="codigoAdminForm" class="itxc">
                <label for="cod_admin">Código de Administrador:</label>
                <input type="text" id="cod_admin" name="cod_admin" required>
                <button type="submit">Verificar</button>
            </form>
        </div>
    </div>

    <div id="miModalDocente" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <p id="mensajeModalDocente"></p>
            <form id="codigoDocenteForm" class="itxc">
                <label for="cod_docente">Código de Docente:</label>
                <input type="text" id="cod_docente" name="cod_docente" required>
                <button type="submit">Verificar</button>
            </form>
        </div>
    </div>

    <script>
    function openNav() {
        document.getElementById("mySidebar").style.width = "250px";
    }

    function closeNav() {
        document.getElementById("mySidebar").style.width = "0";
    }

    function logout() {
        window.location.href = 'logout.php';
    }

    $(document).ready(function() {
        $('#miModal').css('display', 'none');
        $('#miModalDocente').css('display', 'none');

        $('.close').click(function() {
            $('#miModal').css('display', 'none');
            $('#miModalDocente').css('display', 'none');
        });

        $(window).click(function(event) {
            if (event.target === document.getElementById("mySidebar")) {
                closeNav();
            }
        });

        $('#adminButton').click(function() {
            $('#miModal').css('display', 'flex');
        });

        $('#docenteButton').click(function() {
            $('#miModalDocente').css('display', 'flex');
        });

        $('#codigoAdminForm').submit(function(event) {
            event.preventDefault();
            const cod_admin = $('#cod_admin').val();
            $.ajax({
                url: 'verificar.php',
                type: 'POST',
                data: {
                    cod_admin: cod_admin
                },
                dataType: 'json',
                success: function(respuesta) {
                    if (respuesta.status === 'error') {
                        Swal.fire({
                            title: 'Error',
                            text: respuesta.message,
                            icon: 'error',
                            confirmButtonText: 'Aceptar'
                        });
                    } else {
                        Swal.fire({
                            title: '¡Éxito!',
                            text: respuesta.message,
                            icon: 'success',
                            confirmButtonText: 'Aceptar'
                        }).then((result) => {
                            if (result.isConfirmed) {
                                window.location.href = 'seleccion.php';
                            }
                        });
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.log("Response Text: ", jqXHR.responseText);
                    Swal.fire({
                        title: 'Error',
                        text: 'Error en la solicitud: ' + textStatus + ' - ' +
                            errorThrown,
                        icon: 'error',
                        confirmButtonText: 'Aceptar'
                    });
                }
            });
        });

        $('#codigoDocenteForm').submit(function(event) {
            event.preventDefault();
            const cod_docente = $('#cod_docente').val();
            $.ajax({
                url: 'verificar_docente.php',
                type: 'POST',
                data: {
                    cod_docente: cod_docente
                },
                dataType: 'json',
                success: function(respuesta) {
                    if (respuesta.status === 'error') {
                        Swal.fire({
                            title: 'Error',
                            text: respuesta.message,
                            icon: 'error',
                            confirmButtonText: 'Aceptar'
                        });
                    } else {
                        Swal.fire({
                            title: '¡Éxito!',
                            text: respuesta.message,
                            icon: 'success',
                            confirmButtonText: 'Aceptar'
                        }).then((result) => {
                            if (result.isConfirmed) {
                                window.location.href =
                                    `calendario_docente.php?cod_docente=${cod_docente}`;
                            }
                        });
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.log("Response Text: ", jqXHR.responseText);
                    Swal.fire({
                        title: 'Error',
                        text: 'Error en la solicitud: ' + textStatus + ' - ' +
                            errorThrown,
                        icon: 'error',
                        confirmButtonText: 'Aceptar'
                    });
                }
            });
        });
    });
    </script>
</body>

</html>