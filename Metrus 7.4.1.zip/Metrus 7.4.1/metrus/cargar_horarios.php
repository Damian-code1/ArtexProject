<?php
require 'conexion.php';

header('Content-Type: application/json');

$result = $conn->query("SELECT dia, hora, curso, color FROM HorariosGrados");
$horarios = [];
while ($row = $result->fetch_assoc()) {
    $horarios[] = $row;
}

echo json_encode($horarios);

$conn->close();
?>