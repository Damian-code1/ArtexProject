<?php
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit();
}

$courseType = isset($_GET['courseType']) ? htmlspecialchars($_GET['courseType']) : '';
$courseName = isset($_GET['courseName']) ? htmlspecialchars($_GET['courseName']) : '';
$year = isset($_GET['year']) ? htmlspecialchars($_GET['year']) : '';

$yearInitial = $year ? $year[0] : '';

$titulo = "Gestor de Horarios - </h1> <h1 id='grado'>$yearInitial</h1><h1 style='margin-left: 2px;'>º</h1> <h1> $courseType $courseName";
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestor de Horarios</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <style>
        .version-form {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-top: 20px;
        }

        .version-form label {
            margin-right: 10px;
            font-weight: bold;
        }

        .version-form select {
            padding: 10px;
            font-size: 16px;
            border: 2px solid #4b0082;
            border-radius: 5px; 
            background-color: #2e004f;
            color: #e6e6fa;
            margin-right: 10px;
        }

        .version-form button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #4b0082;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }

        .version-form button:hover {
            background-color: #32006d;
        }

        .btn {
            background-color: #4b0082;
            color: white;
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            margin-top: 20px;
        }

        .btn:hover {
            background-color: #32006d;
        }
    </style>
</head>

<body>
    <div class="header">
        <a href="inicio.php" class="logo">metrus.</a>
        <div class="header-right">
            <a href="admin_materias.php">Administrar Materias</a>
        </div>
    </div>

    <div class="main-content">
        <header class="header">
            <div style='display: flex; justify-content: center; align-items: center'><h1><?php echo $titulo; ?></h1></div>
        </header>

        <main>
            <div class="panel">
                <div>
                    <label for="curso">Nombre del curso:</label>
                    <select id="curso" name="curso">
                        <option value="">Seleccione una asignatura</option>
                        <?php
                        $conn = new mysqli('localhost', 'root', '', 'metrus');
                        if ($conn->connect_error) {
                            die("Conexión fallida: {$conn->connect_error}");
                        }
                        $result = $conn->query("SELECT nombre, color FROM Asignaturas");
                        while ($row = $result->fetch_assoc()) {
                            echo "<option value='{$row['nombre']}' data-color='{$row['color']}'>{$row['nombre']}</option>";
                        }
                        ?>
                    </select>
                </div>
                <button id="enable-multi-select">Seleccionar múltiples asignaturas</button>
                <button id="delete-selected-tasks" style="display:none;">Eliminar asignaturas seleccionadas</button>
                <div>
                    <label>Días:</label>
                    <div class="checkboxes">
                        <input type="checkbox" id="lunes" name="lunes"><label for="lunes">L</label>
                        <input type="checkbox" id="martes" name="martes"><label for="martes">M</label>
                        <input type="checkbox" id="miercoles" name="miercoles"><label for="miercoles">X</label>
                        <input type="checkbox" id="jueves" name="jueves"><label for="jueves">J</label>
                        <input type="checkbox" id="viernes" name="viernes"><label for="viernes">V</label>
                    </div>
                </div>

                <div>
                    <label for="hora-desde">Desde:</label>
                    <select id="hora-desde">
                        <option value="07:30">07:30</option>
                        <option value="08:15">08:15</option>
                        <option value="09:00">09:00</option>
                        <option value="09:50">09:50</option>
                        <option value="10:50">10:50</option>
                        <option value="11:35">11:35</option>
                        <option value="12:20">12:20</option>
                        <option value="13:10">13:10</option>
                        <option value="14:30">14:30</option>
                    </select>
                </div>

                <div>
                    <label for="hora-hasta">Hasta:</label>
                    <select id="hora-hasta">
                        <option value="08:15">08:15</option>
                        <option value="08:55">08:55</option>
                        <option value="09:45">09:45</option>
                        <option value="10:35">10:35</option>
                        <option value="11:35">11:35</option>
                        <option value="12:15">12:15</option>
                        <option value="13:05">13:05</option>
                        <option value="13:55">13:55</option>
                        <option value="15:15">15:15</option>
                    </select>
                </div>

                <button id="agregar"><i class="fas fa-plus"></i> Agregar</button>
                <button id="guardar-horarios"><i class="fas fa-save"></i> Guardar Horarios</button>
            </div>

            <div id="error-message" class="error"></div>

            <table class="horario">
                <thead>
                    <tr>
                        <th>Horas</th>
                        <th>(L) Lunes</th>
                        <th>(M) Martes</th>
                        <th>(X) Miércoles</th>
                        <th>(J) Jueves</th>
                        <th>(V) Viernes</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>07:30 - 08:15</td>
                        <td data-dia="lunes" data-hora="07:30-08:15"></td>
                        <td data-dia="martes" data-hora="07:30-08:15"></td>
                        <td data-dia="miercoles" data-hora="07:30-08:15"></td>
                        <td data-dia="jueves" data-hora="07:30-08:15"></td>
                        <td data-dia="viernes" data-hora="07:30-08:15"></td>
                    </tr>
                    <tr>
                        <td>08:15 - 08:55</td>
                        <td data-dia="lunes" data-hora="08:15-08:55"></td>
                        <td data-dia="martes" data-hora="08:15-08:55"></td>
                        <td data-dia="miercoles" data-hora="08:15-08:55"></td>
                        <td data-dia="jueves" data-hora="08:15-08:55"></td>
                        <td data-dia="viernes" data-hora="08:15-08:55"></td>
                    </tr>
                    <tr>
                        <td>09:00 - 09:45</td>
                        <td data-dia="lunes" data-hora="09:00-09:45"></td>
                        <td data-dia="martes" data-hora="09:00-09:45"></td>
                        <td data-dia="miercoles" data-hora="09:00-09:45"></td>
                        <td data-dia="jueves" data-hora="09:00-09:45"></td>
                        <td data-dia="viernes" data-hora="09:00-09:45"></td>
                    </tr>
                    <tr>
                        <td>09:50 - 10:35</td>
                        <td data-dia="lunes" data-hora="09:50-10:35"></td>
                        <td data-dia="martes" data-hora="09:50-10:35"></td>
                        <td data-dia="miercoles" data-hora="09:50-10:35"></td>
                        <td data-dia="jueves" data-hora="09:50-10:35"></td>
                        <td data-dia="viernes" data-hora="09:50-10:35"></td>
                    </tr>
                    <tr>
                        <td>10:50 - 11:35</td>
                        <td data-dia="lunes" data-hora="10:50-11:35"></td>
                        <td data-dia="martes" data-hora="10:50-11:35"></td>
                        <td data-dia="miercoles" data-hora="10:50-11:35"></td>
                        <td data-dia="jueves" data-hora="10:50-11:35"></td>
                        <td data-dia="viernes" data-hora="10:50-11:35"></td>
                    </tr>
                    <tr>
                        <td>11:35 - 12:15</td>
                        <td data-dia="lunes" data-hora="11:35-12:15"></td>
                        <td data-dia="martes" data-hora="11:35-12:15"></td>
                        <td data-dia="miercoles" data-hora="11:35-12:15"></td>
                        <td data-dia="jueves" data-hora="11:35-12:15"></td>
                        <td data-dia="viernes" data-hora="11:35-12:15"></td>
                    </tr>
                    <tr>
                        <td>12:20 - 13:05</td>
                        <td data-dia="lunes" data-hora="12:20-13:05"></td>
                        <td data-dia="martes" data-hora="12:20-13:05"></td>
                        <td data-dia="miercoles" data-hora="12:20-13:05"></td>
                        <td data-dia="jueves" data-hora="12:20-13:05"></td>
                        <td data-dia="viernes" data-hora="12:20-13:05"></td>
                    </tr>
                    <tr>
                        <td>13:10 - 13:55</td>
                        <td data-dia="lunes" data-hora="13:10-13:55"></td>
                        <td data-dia="martes" data-hora="13:10-13:55"></td>
                        <td data-dia="miercoles" data-hora="13:10-13:55"></td>
                        <td data-dia="jueves" data-hora="13:10-13:55"></td>
                        <td data-dia="viernes" data-hora="13:10-13:55"></td>
                    </tr>
                    <tr>
                        <td>14:30 - 15:15</td>
                        <td data-dia="lunes" data-hora="14:30-15:15"></td>
                        <td data-dia="martes" data-hora="14:30-15:15"></td>
                        <td data-dia="miercoles" data-hora="14:30-15:15"></td>
                        <td data-dia="jueves" data-hora="14:30-15:15"></td>
                        <td data-dia="viernes" data-hora="14:30-15:15"></td>
                    </tr>
                </tbody>
            </table>
        </main>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="js/jquery-3.7.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>
    <script src="js/script.js"></script>
    <script src="js/scripts.js"></script>
    <script>
        document.getElementById('versiones-btn').addEventListener('click', function() {
            $.ajax({
                url: 'cargar_versiones.php',
                type: 'GET',
                success: function(response) {
                    const versiones = JSON.parse(response);
                    let options = '';
                    versiones.forEach(version => {
                        options += `<option value="${version.version}">Versión ${version.version}</option>`;
                    });

                    Swal.fire({
                        title: 'Seleccionar Versión',
                        html: `<select id="version-select" class="swal2-input">${options}</select>`,
                        showCancelButton: true,
                        confirmButtonText: 'Aceptar',
                        cancelButtonText: 'Cancelar',
                        preConfirm: () => {
                            const version = Swal.getPopup().querySelector('#version-select').value;
                            return { version: version };
                        }
                    }).then((result) => {
                        if (result.isConfirmed) {
                            console.log('Versión seleccionada:', result.value.version);
                        }
                    });
                },
                error: function(xhr, status, error) {
                    console.error('Error al cargar las versiones:', error);
                }
            });
        });
    </script>
</body>

</html> 