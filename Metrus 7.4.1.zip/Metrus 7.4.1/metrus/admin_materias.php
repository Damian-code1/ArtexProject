
<?php
    session_start();
    if (!isset($_SESSION['user'])) {
        header('Location: login.php');
        exit();
    }
    $user = $_SESSION['user'];
    ?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrar Materias - Metrus</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
    body {
        background-color: #4b0082;
        color: white;
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        display: flex;
        height: 100vh;
    }

    /* Sidebar */
    .sidebar {
        width: 250px;
        height: 100vh;
        background: linear-gradient(to bottom, #4b0082, #000000);
        color: white;
        display: flex;
        flex-direction: column;
        align-items: center;
        padding-top: 20px;
        transition: width 0.3s;
        position: fixed;
        left: 0;
        top: 0;
        z-index: 1000;
    }

    .sidebar.collapsed {
        width: 80px;
    }

    .sidebar .logo {
        display: flex;
        align-items: center;
        padding: 10px;
    }

    .sidebar .logo img {
        width: 30px;
        margin-right: 10px;
    }

    .sidebar .logo span {
        font-weight: bold;
        font-size: 1.2em;
    }

    .sidebar .nav {
        list-style: none;
        width: 100%;
        padding: 0;
    }

    .sidebar .nav li {
        width: 100%;
        margin: 15px 0;
    }

    .sidebar .nav a {
        color: white;
        text-decoration: none;
        padding: 10px;
        width: 100%;
        display: flex;
        align-items: center;
        transition: background 0.3s;
    }

    .sidebar .nav a:hover {
        background: rgba(255, 255, 255, 0.2);
    }

    .sidebar .nav a i {
        font-size: 1.2em;
        margin-right: 10px;
    }

    .sidebar .profile {
        margin-top: auto;
        display: flex;
        align-items: center;
        padding: 15px;
        width: 100%;
        background: rgba(255, 255, 255, 0.1);
    }

    .sidebar .profile img {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        margin-right: 10px;
    }

    /* Responsive Sidebar */
    @media (max-width: 768px) {
        .sidebar {
            width: 80px;
        }
        
        .sidebar .logo span, 
        .sidebar .nav a span, 
        .sidebar .profile div {
            display: none;
        }
        
        .sidebar .nav a i {
            margin-right: 0;
        }
    }

    /* Main content styles */
    .container {
        margin-left: 250px;
        width: calc(100% - 250px);
        padding: 20px;
        transition: margin-left 0.3s;
    }

    .container.collapsed {
        margin-left: 80px;
        width: calc(100% - 80px);
    }

    @media (max-width: 768px) {
        .container {
            margin-left: 80px;
            width: calc(100% - 80px);
        }
    }

    .header {
        background-color: #32006d;
        color: white;
        padding: 20px 0;
        text-align: center;
        width: 100%;
    }

    .header a {
        color: white;
        text-decoration: none;
        font-size: 24px;
    }

    .main-content {
        background-color: #32006d;
        padding: 40px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        margin-top: 80px;
        text-align: center;
        width: 100%;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-group label {
        display: block;
        margin-bottom: 5px;
    }

    .form-group input,
    .form-group select {
        width: 100%;
        padding: 10px;
        border: 2px solid #4b0082;
        border-radius: 5px;
        background-color: #2e004f;
        color: #e6e6fa;
    }

    .form-group button {
        padding: 10px 20px;
        font-size: 16px;
        background-color: #4b0082;
        color: white;
        border: none;
        cursor: pointer;
        border-radius: 5px;
    }

    .form-group button:hover {
        background-color: #6c3483;
    }

    .materias-list {
        margin-top: 20px;
    }

    .materias-list table {
        width: 100%;
        border-collapse: collapse;
    }

    .materias-list th,
    .materias-list td {
        padding: 10px;
        border: 1px solid #4b0082;
    }

    .materias-list th {
        background-color: #32006d;
    }

    .materias-list td {
        background-color: #4b0082;
    }

    .toggle-btn {
        position: absolute;
        top: 20px;
        left: 20px;
        font-size: 24px;
        cursor: pointer;
        z-index: 1100;
    }
    </style>
</head>

<body>

    <!-- Toggle button -->
    <div class="toggle-btn" onclick="toggleSidebar()">
        <i class="fas fa-bars"></i>
    </div>

    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo">
            <img src="logo.png" alt="Logo">
            <span>CursosCSS</span>
        </div>
        <ul class="nav">
            <li><a href="#dashboard"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a></li>
            <li><a href="#orders"><i class="fas fa-box"></i><span>Orders</span></a></li>
            <li><a href="#schedule"><i class="fas fa-calendar-alt"></i><span>Schedule</span></a></li>
            <li><a href="#messages"><i class="fas fa-envelope"></i><span>Messages</span></a></li>
            <li><a href="#analytics"><i class="fas fa-chart-line"></i><span>Analytics</span></a></li>
            <li><a href="#settings"><i class="fas fa-cog"></i><span>Settings</span></a></li>
        </ul>
        <div class="profile">
            <img src="profile.png" alt="Profile">
            <div>
                <span><?php echo htmlspecialchars($user['nombre']); ?></span>
                <small>Cuenta Free</small>
            </div>
        </div>
    </div>

    <!-- Main content -->
    <div class="header">
        <a href="inicio.php">metrus.</a>
    </div>
    <div class="container">
        <div class="main-content">
            <h1>Administrar Materias</h1>
            <form id="materiaForm">
                <div class="form-group">
                    <label for="nombre">Nombre de la Materia:</label>
                    <input type="text" id="nombre" name="nombre" required>
                </div>
                <div class="form-group">
                    <label for="descripcion">Descripción:</label>
                    <input type="text" id="descripcion" name="descripcion" required>
                </div>
                <div class="form-group">
                    <label for="orientacion">Orientación:</label>
                    <input type="text" id="orientacion" name="orientacion" required>
                </div>
                <div class="form-group-color">
                    <label for="color">Color:</label> <br>
                    <input type="color" id="color" name="color" class="color-picker" required>
                </div>
                <div class="form-group">
                    <button type="button" onclick="agregarMateria()">Agregar Materia</button>
                </div>
            </form>

            <div class="materias-list">
                <h2>Materias Existentes</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Descripción</th>
                            <th>Orientación</th>
                            <th>Color</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody id="materiasTableBody">
                        <?php
                        $conn = new mysqli('localhost', 'root', '', 'metrus');
                        if ($conn->connect_error) {
                            die("Conexión fallida: " . $conn->connect_error);
                        }

                        $result = $conn->query("SELECT * FROM Asignaturas");
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>
                                    <td>{$row['nombre']}</td>
                                    <td>{$row['descripcion']}</td>
                                    <td>{$row['orientacion']}</td>
                                    <td class='color-preview'>
                                        {$row['color']}
                                        <div class='color-box' style='background-color: {$row['color']};'></div>
                                    </td>
                                    <td>
                                        <button class='btn btn-danger' onclick='confirmDelete(\"{$row['nombre']}\")'>Eliminar</button>
                                        <button class='btn edit-button' onclick='editColor(\"{$row['nombre']}\", \"{$row['color']}\")'>Editar Color</button>
                                    </td>
                                  </tr>";
                        }
                        $conn->close();
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    function toggleSidebar() {
        const sidebar = document.querySelector('.sidebar');
        const container = document.querySelector('.container');
        const toggleBtnIcon = document.querySelector('.toggle-btn i');

        sidebar.classList.toggle('collapsed');
        container.classList.toggle('collapsed');

        if (sidebar.classList.contains('collapsed')) {
            toggleBtnIcon.classList.remove('fa-bars');
            toggleBtnIcon.classList.add('fa-times');
        } else {
            toggleBtnIcon.classList.remove('fa-times');
            toggleBtnIcon.classList.add('fa-bars');
        }
    }

    function agregarMateria() {
        var nombre = $('#nombre').val();
        var descripcion = $('#descripcion').val();
        var orientacion = $('#orientacion').val();
        var color = $('#color').val();

        $.ajax({
            url: 'agregar_materia.php',
            type: 'POST',
            data: {
                nombre: nombre,
                descripcion: descripcion,
                orientacion: orientacion,
                color: color
            },
            success: function(response) {
                Swal.fire({
                    icon: 'success',
                    title: 'Éxito',
                    text: 'Materia agregada exitosamente.',
                }).then(() => {
                    window.location.reload();
                });
            },
            error: function() {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Hubo un problema al agregar la materia.',
                });
            }
        });
    }

    function confirmDelete(nombre) {
        Swal.fire({
            title: '¿Estás seguro de querer eliminar esta materia?',
            text: 'Esta acción no se puede deshacer.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Aceptar'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'delete_materia.php',
                    type: 'POST',
                    data: {
                        nombre: nombre
                    },
                    success: function(response) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Éxito',
                            text: 'Materia eliminada exitosamente.',
                        }).then(() => {
                            window.location.reload();
                        });
                    },
                    error: function() {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Hubo un problema al eliminar la materia.',
                        });
                    }
                });
            }
        });
    }

    function editColor(nombre, colorActual) {
        Swal.fire({
            title: 'Editar Color',
            html: `<input type="color" id="newColor" value="${colorActual}" class="swal2-input">`,
            showCancelButton: true,
            confirmButtonText: 'Guardar',
            cancelButtonText: 'Cancelar',
            preConfirm: () => {
                const newColor = Swal.getPopup().querySelector('#newColor').value;
                return { newColor: newColor };
            }
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'editar_color.php',
                    type: 'POST',
                    data: {
                        nombre: nombre,
                        color: result.value.newColor
                    },
                    success: function(response) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Éxito',
                            text: 'Color actualizado exitosamente.',
                        }).then(() => {
                            window.location.reload();
                        });
                    },
                    error: function() {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Hubo un problema al actualizar el color.',
                        });
                    }
                });
            }
        });
    }
    </script>
</body>

</html>