<?php
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit();
}
$user = $_SESSION['user'];
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Selección de Cursos - Metrus</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
    body {
        font-family: Arial, sans-serif;
        background-color: #4b0082;
        color: white;
        margin: 0;
        padding: 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 100vh;
        overflow: hidden;
    }

    header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        background-color: #32006d;
        padding: 10px;
        width: 100%;
        position: fixed;
        top: 0;
        z-index: 1000;
    }

    .menu-icon {
        font-size: 30px;
        color: white;
        cursor: pointer;
    }

    .logoo h1 {
        margin: 0;
        font-size: 24px;
        font-weight: bold;
        color: white;
    }

    .logoo h1 a {
        color: white;
        text-decoration: none;
    }

    .user-info {
        color: white;
        font-size: 18px;
    }

    .sidebar {
        height: 100%;
        width: 0;
        position: fixed;
        z-index: 1001;
        top: 0;
        left: 0;
        background-color: #4b0082;
        overflow-x: hidden;
        transition: 0.5s;
        padding-top: 60px;
        box-shadow: 2px 0 5px rgba(0, 0, 0, 0.5);
    }

    .sidebar a {
        padding: 10px 15px;
        text-decoration: none;
        font-size: 25px;
        color: white;
        display: block;
        transition: 0.3s;
    }

    .sidebar a:hover {
        background-color: #1f004a;
    }

    .sidebar .closebtn {
        position: absolute;
        top: 0;
        right: 25px;
        font-size: 36px;
        margin-left: 50px;
    }

    .sidebar .user-info {
        margin-top: 20px;
        padding: 10px 15px;
        font-size: 18px;
        color: white;
        text-align: center;
        border-bottom: 1px solid #6c3483;
    }

    .sidebar .logout-btn {
        position: absolute;
        bottom: 20px;
        left: 20px;
        right: 20px;
        padding: 10px 20px;
        background-color: #4b0082;
        color: white;
        border: none;
        cursor: pointer;
        border-radius: 5px;
        transition: background-color 0.3s;
        text-align: center;
    }

    .sidebar .logout-btn:hover {
        background-color: #6c3483;
    }

    main {
        margin-top: 70px;
        text-align: center;
        width: 100%;
    }

    h1 {
        font-size: 36px;
        margin-bottom: 40px;
        color: white;
    }

    .container {
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
        height: 100%;
    }

    .course-option {
        margin-bottom: 20px;
        display: flex;
        justify-content: center;
        align-items: center;
        animation: fadeInUp 0.5s ease-in-out;
    }

    .card {
        background-color: #6A329F;
        color: white;
        border: none;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        height: 350px;
        width: 300px;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        align-items: center;
        padding: 20px;
    }

    .card:hover {
        transform: scale(1.05);
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
    }

    .card-body {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        height: 100%;
    }

    .card-body h2 {
        font-size: 28px;
        margin-bottom: 20px;
    }

    .btn-primary {
        background-color: #32006d;
        border: none;
        padding: 10px 20px;
        border-radius: 5px;
        transition: background-color 0.3s ease;
        margin-top: auto;
    }

    .btn-primary:hover {
        background-color: #1f004a;
    }

    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .swal2-popup {
        padding: 0;
    }

    .swal2-title {
        margin: 0;
        padding: 20px;
        background-color: white;
        color: white;
        border-top-left-radius: 10px;
        border-top-right-radius: 10px;
    }

    .swal2-content {
        padding: 20px;
        color: white;
        background-color: white;
    }

    .back-arrow {
        position: absolute;
        top: 10px;
        left: 10px;
        font-size: 24px;
        color: gray;
        cursor: pointer;
    }

    .back-arrow:hover {
        color: white;
    }

    .cursoh1{
        justify-content: center;
        align-items: center;
        text-align: center;
    }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
</head>

<body>
    <header>
        <span class="menu-icon" onclick="openNav()"><i class="fas fa-bars"></i></span>
        <div class="logoo">
            <h1><a href="inicio.php">metrus.</a></h1>
        </div>
        <div class="user-info">
            <?php echo htmlspecialchars($user['nombre']); ?>
        </div>
    </header>

    <div id="mySidebar" class="sidebar">
        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
        <div class="user-info">
            <?php echo htmlspecialchars($user['nombre']); ?>
        </div>
        <button class="logout-btn" onclick="logout()">Cerrar Sesión</button>
    </div>

    <div class="container">
        <div class="main-content">
            <h1 class="cursoh1">Seleccione un Curso</h1>
            <div class="row justify-content-center">
                <div class="col-md-6 course-option">
                    <div class="card">
                        <div class="card-body text-center">
                            <h2>EMP</h2>
                            <a href="#" class="btn btn-primary" onclick="showEmpModal()">Seleccionar EMP</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 course-option">
                    <div class="card">
                        <div class="card-body text-center">
                            <h2>EMT</h2>
                            <a href="#" class="btn btn-primary" onclick="showEmtModal()">Seleccionar EMT</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
    function openNav() {
        document.getElementById("mySidebar").style.width = "250px";
    }

    function closeNav() {
        document.getElementById("mySidebar").style.width = "0";
    }

    function logout() {
        window.location.href = 'logout.php';
    }

    function showEmpModal() {
        Swal.fire({
            title: 'Seleccione una opción de EMP',
            html: `
                <i class="fas fa-arrow-left back-arrow" onclick="showCourseOptions()"></i>
                <div class="d-grid gap-2">
                    <button class="btn btn-primary" onclick="showYearOptions('EMP', 'Carpintería')">Carpintería</button>
                    <button class="btn btn-primary" onclick="showYearOptions('EMP', 'Mecánica Automotriz')">Mecánica Automotriz</button>
                    <button class="btn btn-primary" onclick="showYearOptions('EMP', 'Mecánica Industrial')">Mecánica Industrial</button>
                    <button class="btn btn-primary" onclick="showYearOptions('EMP', 'Deporte')">Deporte</button>
                </div>
            `,
            showConfirmButton: false,
            backdrop: true,
            customClass: {
                popup: 'animate__animated animate__fadeInDown'
            }
        });
    }

    function showEmtModal() {
        Swal.fire({
            title: 'Seleccione una opción de EMT',
            html: `
                <i class="fas fa-arrow-left back-arrow" onclick="showCourseOptions()"></i>
                <div class="d-grid gap-2">
                    <button class="btn btn-primary" onclick="showYearOptions('EMT', 'Instalaciones Eléctricas')">Instalaciones Eléctricas</button>
                    <button class="btn btn-primary" onclick="showYearOptions('EMT', 'Informática')">Informática</button>
                    <button class="btn btn-primary" onclick="showYearOptions('EMT', 'Administración')">Administración</button>
                </div>
            `,
            showConfirmButton: false,
            backdrop: true,
            customClass: {
                popup: 'animate__animated animate__fadeInDown'
            }
        });
    }

    function showYearOptions(courseType, courseName) {
        Swal.fire({
            title: 'Seleccione el Año',
            html: `
                <i class="fas fa-arrow-left back-arrow" onclick="showCourseOptions()"></i>
                <div class="d-grid gap-2">
                    <button class="btn btn-primary" onclick="selectCourse('${courseType}', '${courseName}', '1ro')">1ro</button>
                    <button class="btn btn-primary" onclick="selectCourse('${courseType}', '${courseName}', '2do')">2do</button>
                    <button class="btn btn-primary" onclick="selectCourse('${courseType}', '${courseName}', '3ro')">3ro</button>
                </div>
            `,
            showConfirmButton: false,
            backdrop: true,
            customClass: {
                popup: 'animate__animated animate__fadeInDown'
            }
        });
    }

    function showCourseOptions() {
        Swal.fire({
            title: 'Seleccione un Curso',
            html: `
                <div class="d-grid gap-2">
                    <button class="btn btn-primary" onclick="showEmpModal()">EMP</button>
                    <button class="btn btn-primary" onclick="showEmtModal()">EMT</button>
                </div>
            `,
            showConfirmButton: false,
            backdrop: true,
            customClass: {
                popup: 'animate__animated animate__fadeInDown'
            }
        });
    }

    function selectCourse(courseType, courseName, year) {
        Swal.fire({
            title: 'Cargando...',
            html: '<div class="spinner-border text-light" role="status"><span class="sr-only">Cargando...</span></div>',
            showConfirmButton: false,
            allowOutsideClick: false,
            didOpen: () => {
                window.location.href = `calendario.php?courseType=${courseType}&courseName=${courseName}&year=${year}`;
            }
        });
    }

    window.addEventListener('pageshow', (event) => {
        if (event.persisted) {
            Swal.close();
        }
    });
    </script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>