<?php
header('Content-Type: application/json');
require_once 'conexion.php';

$ci = $_POST['ci'];
$mail = $_POST['mail'];
$password = $_POST['password'];

if (empty($ci) || empty($mail) || empty($password)) {
    die(json_encode(["status" => "error", "message" => "Todos los campos son obligatorios."]));
}

$conexion = Conectar::conexion();

$sql_check = "SELECT * FROM Personas WHERE ci = ? OR mail = ?";
$stmt_check = $conexion->prepare($sql_check);
$stmt_check->bind_param("ss", $ci, $mail);
$stmt_check->execute();
$result_check = $stmt_check->get_result();

if ($result_check->num_rows > 0) {
    echo json_encode(["status" => "error", "message" => "El usuario ya existe."]);
} else {
    $sql_insert = "INSERT INTO Personas (ci, mail, contraseña) VALUES (?, ?, ?)";
    $stmt_insert = $conexion->prepare($sql_insert);
    $stmt_insert->bind_param("sss", $ci, $mail, $password);

    if ($stmt_insert->execute()) {
        echo json_encode(["status" => "success", "message" => "Registro exitoso"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Error al registrar el usuario."]);
    }

    $stmt_insert->close();
}

$stmt_check->close();
$conexion->close();
?>