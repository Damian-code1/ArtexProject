<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Metrus - Iniciar Sesión</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
    body {
        background-color: #000;
        color: #fff;
        font-family: 'Arial', sans-serif;
        margin: 0;
        padding: 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 100vh;
    }

    .container {
        max-width: 400px;
        padding: 20px;
        background-color: #1a1a1a;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .logo {
        width: 150px;
        margin-bottom: 20px;
        border-radius: 20px;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-control {
        background-color: #333;
        border: none;
        color: #fff;
    }

    .form-control:focus {
        background-color: #444;
        color: #fff;
    }

    .btn-custom {
        background-color: #6A329F;
        color: #fff;
        border: none;
        padding: 10px 20px;
        font-size: 18px;
        border-radius: 5px;
        transition: background-color 0.3s ease;
        width: 100%;
    }

    .btn-custom:hover {
        background-color: #9C4FE5;
    }

    .toggle-password {
        position: absolute;
        right: 10px;
        top: 50%;
        transform: translateY(-50%);
        cursor: pointer;
        font-size: 18px;
        color: #fff;
    }

    #loadingIndicator {
        display: none;
        text-align: center;
        margin-top: 10px;
        color: #fff;
    }
    </style>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
</head>

<body>
    <div class="container text-center animate__animated animate__fadeIn">
        <a href="inicio.php"><img src="img/Metrus.png" alt="Logo Metrus" class="logo"></a>
        <h1 class="mb-4">Iniciar Sesión</h1>
        <form id="loginForm" method="post">
            <div class="form-group">
                <input type="text" id="ci" class="form-control" placeholder="CI" required>
            </div>
            <div class="form-group position-relative">
                <input type="password" id="password" class="form-control" placeholder="Contraseña" required>
                <span class="toggle-password">&#128065;</span>
            </div>
            <button type="submit" class="btn btn-custom">Entrar</button>
        </form>
        <div id="loadingIndicator">Conectando...</div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
    $(document).ready(function() {
        $('.toggle-password').click(function() {
            const passwordField = $('#password');
            const type = passwordField.attr('type') === 'password' ? 'text' : 'password';
            passwordField.attr('type', type);
            $(this).html(type === 'password' ? '&#128065;' : '&#128065;');
        });

        function validateForm() {
            const ci = $('#ci').val();
            const password = $('#password').val();

            if (ci.length !== 8 || !/^\d+$/.test(ci)) {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'El CI debe tener exactamente 8 caracteres y no pueden ser letras.'
                }).then(() => {
                    $('#ci').focus();
                });
                $('#loadingIndicator').hide();
                return false;
            }

            if (password.length <= 4) {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'La contraseña debe tener más de 4 caracteres.'
                }).then(() => {
                    $('#password').focus();
                });
                $('#loadingIndicator').hide();
                return false;
            }

            return true;
        }

        $('#loginForm').submit(function(e) {
            e.preventDefault();
            $('#loadingIndicator').show();

            if (!validateForm()) {
                return;
            }

            const ci = $('#ci').val();
            const password = $('#password').val();

            $.ajax({
                url: 'login_handler.php',
                type: 'POST',
                data: {
                    ci: ci,
                    password: password
                },
                dataType: 'json',
                success: function(response) {
                    $('#loadingIndicator').hide();
                    if (response.success) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Éxito',
                            text: response.message,
                            confirmButtonText: 'Aceptar'
                        }).then((result) => {
                            if (result.isConfirmed) {
                                window.location.href = 'rol.php';
                            }
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: response.message || 'Usuario o contraseña incorrectos.'
                        }).then(() => {
                            $('#ci').focus();
                        });
                    }
                },
                error: function(xhr, status, error) {
                    $('#loadingIndicator').hide();
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Ocurrió un error al iniciar sesión.'
                    }).then(() => {
                        $('#ci').focus();
                    });
                }
            });
        });
    });
    </script>
</body>

</html>