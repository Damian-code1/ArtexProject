<?php
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'];
    $color = $_POST['color'];

    $conn = new mysqli('localhost', 'root', '', 'metrus');
    if ($conn->connect_error) {
        die("Conexión fallida: {$conn->connect_error}");
    }

    $stmt = $conn->prepare("UPDATE Asignaturas SET color = ? WHERE nombre = ?");
    $stmt->bind_param('ss', $color, $nombre);

    if ($stmt->execute()) {
        echo "Color actualizado correctamente.";
    } else {
        echo "Error al actualizar el color: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>