document.getElementById('guardar-horarios').addEventListener('click', function() {
    mostrarPopupGuardar();
});

function mostrarPopupGuardar() {
    Swal.fire({
        title: 'Guardar Horarios',
        text: "Elija el formato para guardar:",
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'PDF',
        cancelButtonText: 'PNG'
    }).then((result) => {
        if (result.isConfirmed) {
            guardarHorarioPDF();
        } else if (result.dismiss === Swal.DismissReason.cancel) {
            guardarHorarioPNG();
        }
    });
}

function guardarHorarioPDF() {
    const { jsPDF } = window.jspdf;

    html2canvas(document.querySelector(".horario")).then(canvas => {
        const imgData = canvas.toDataURL("image/png");
        const pdf = new jsPDF('p', 'mm', 'a4');
        const imgWidth = 190;
        const pageHeight = pdf.internal.pageSize.height;
        const imgHeight = canvas.height * imgWidth / canvas.width;
        let position = 10;

        pdf.addImage(imgData, 'PNG', 10, position, imgWidth, imgHeight);
        pdf.save("horario.pdf");
    });
}

function guardarHorarioPNG() {
    html2canvas(document.querySelector(".horario")).then(canvas => {
        const link = document.createElement('a');
        link.href = canvas.toDataURL("image/png");
        link.download = 'horario.png';
        link.click();
    });
}