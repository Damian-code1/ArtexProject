document.getElementById("agregar").addEventListener("click", function() {
    var curso = document.getElementById("curso").value;
    var dias = Array.from(
        document.querySelectorAll(".checkboxes input:checked")
    ).map((cb) => cb.id);
    var horaDesde = document.getElementById("hora-desde").value;
    var horaHasta = document.getElementById("hora-hasta").value;
    var grado = document.getElementById("grado").value;

    if (curso === "" || dias.length === 0 || horaDesde >= horaHasta) {
        Swal.fire({
            icon: "error",
            title: "Error",
            text: "Por favor, complete todos los campos y asegúrese de que la hora de inicio sea menor que la hora de fin.",
        });
        return;
    }

    const horas = [
        "07:30-08:15",
        "08:15-08:55",
        "09:00-09:45",
        "09:50-10:35",
        "10:50-11:35",
        "11:35-12:15",
        "12:20-13:05",
        "13:10-13:55",
        "14:30-15:15",
    ];

    const indiceInicio = horas.findIndex((h) => h.split("-")[0] === horaDesde);
    const indiceFin = horas.findIndex((h) => h.split("-")[1] === horaHasta);

    if (indiceInicio === -1 || indiceFin === -1 || indiceInicio > indiceFin) {
        Swal.fire({
            icon: "error",
            title: "Error",
            text: "Las horas seleccionadas no son válidas.",
        });
        return;
    }

    let error = false;

    dias.forEach((dia) => {
        for (let i = indiceInicio; i <= indiceFin; i++) {
            const celda = document.querySelector(
                `td[data-dia="${dia}"][data-hora="${horas[i]}"]`
            );
            if (celda) {
                if (celda.innerHTML !== "") {
                    error = true;
                    break;
                } else {
                    celda.style.backgroundColor =
                        document.getElementById("curso").selectedOptions[0].dataset.color;
                    celda.innerHTML = curso;
                    celda.style.cursor = "pointer";
                    guardarHorarioEnBD(
                        dia,
                        horas[i],
                        curso,
                        celda.style.backgroundColor,
                        grado
                    );
                }
            }
        }
    });

    if (error) {
        Swal.fire({
            icon: "error",
            title: "Error",
            text: "Una o más celdas ya están ocupadas.",
        });
    } else {
        Swal.fire({
            icon: "success",
            title: "Éxito",
            text: "Horario agregado correctamente.",
        });
        document.getElementById("curso").value = "";
        document
            .querySelectorAll('input[type="checkbox"]')
            .forEach((cb) => (cb.checked = false));
    }
});

function guardarHorarioEnBD(dia, hora, curso, color, grado) {
    $.ajax({
        url: "guardar_horario.php",
        type: "POST",
        data: {
            dia: dia,
            hora: hora,
            curso: curso,
            color: color,
            grado: grado,
            // Agrega los datos necesarios para la tabla Pertenece
            año_D: new Date().getFullYear(), // Ejemplo de año actual
            ci_D: "ci_docente", // Reemplaza con el valor correcto
            nombre_A: curso,
            nombre_G: "nombre_grupo", // Reemplaza con el valor correcto
            id_G: 1 // Reemplaza con el valor correcto
        },
        success: function(response) {
            console.log("Horario guardado en la base de datos.");
        },
        error: function(xhr, status, error) {
            console.error("Error al guardar el horario en la base de datos:", error);
        },
    });
}

function cargarHorarios() {
    $.ajax({
        url: "cargar_horarios.php",
        type: "GET",
        success: function(response) {
            try {
                const horarios = JSON.parse(response);
                horarios.forEach((horario) => {
                    const celda = document.querySelector(
                        `td[data-dia="${horario.dia}"][data-hora="${horario.hora}"]`
                    );
                    if (celda) {
                        celda.style.backgroundColor = horario.color;
                        celda.innerHTML = horario.curso;
                        celda.style.cursor = "pointer";
                    }
                });
            } catch (error) {
                console.error("Error al analizar JSON:", error);
                console.log("Respuesta del servidor:", response);
            }
        },
        error: function(xhr, status, error) {
            console.error(
                "Error al cargar los horarios desde la base de datos:",
                error
            );
        },
    });
}

document.addEventListener("DOMContentLoaded", function() {
    cargarHorarios();
});

let seleccionMultipleHabilitada = false;
let celdasSeleccionadas = [];
let isMouseDown = false;

document
    .getElementById("enable-multi-select")
    .addEventListener("click", function() {
        seleccionMultipleHabilitada = !seleccionMultipleHabilitada;
        if (seleccionMultipleHabilitada) {
            this.textContent = "Cancelar";
            document.getElementById("delete-selected-tasks").style.display = "block";
        } else {
            this.textContent = "Seleccionar múltiples asignaturas";
            document.getElementById("delete-selected-tasks").style.display = "none";
            celdasSeleccionadas.forEach(
                (celda) => (celda.style.backgroundColor = celda.dataset.originalColor)
            );
            celdasSeleccionadas = [];
        }
    });

document.addEventListener("mousedown", function(event) {
    if (
        seleccionMultipleHabilitada &&
        event.target.tagName === "TD" &&
        event.target.dataset.dia
    ) {
        isMouseDown = true;
        toggleCeldaSeleccionada(event.target);
        event.preventDefault();
    }
});

document.addEventListener("mouseover", function(event) {
    if (
        seleccionMultipleHabilitada &&
        isMouseDown &&
        event.target.tagName === "TD" &&
        event.target.dataset.dia
    ) {
        toggleCeldaSeleccionada(event.target);
    }
});

document.addEventListener("mouseup", function() {
    isMouseDown = false;
});

function toggleCeldaSeleccionada(celda) {
    if (celda.textContent.trim() === "") {
        return;
    }
    if (celdasSeleccionadas.includes(celda)) {
        celda.style.backgroundColor = celda.dataset.originalColor;
        celdasSeleccionadas = celdasSeleccionadas.filter((c) => c !== celda);
    } else {
        celda.dataset.originalColor = celda.style.backgroundColor;
        celda.style.backgroundColor = "yellow";
        celdasSeleccionadas.push(celda);
    }
}

document.addEventListener("click", function(event) {
    if (!seleccionMultipleHabilitada &&
        event.target.tagName === "TD" &&
        event.target.dataset.dia
    ) {
        const celda = event.target;
        if (celda.textContent.trim() === "") {
            return;
        }
        Swal.fire({
            title: "¿Estás seguro de querer eliminar esta asignatura?",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Aceptar",
            cancelButtonText: "Cancelar",
        }).then((result) => {
            if (result.isConfirmed) {
                celda.style.backgroundColor = "";
                celda.textContent = "";
                celda.style.cursor = "default";
                eliminarHorarioDeBD(celda.dataset.dia, celda.dataset.hora);
                Swal.fire("Eliminado", "La asignatura ha sido eliminada.", "success");
            }
        });
    }
});

document
    .getElementById("delete-selected-tasks")
    .addEventListener("click", function() {
        if (celdasSeleccionadas.length === 0) {
            Swal.fire({
                icon: "error",
                title: "Error",
                text: "No hay asignaturas seleccionadas para eliminar.",
            });
            return;
        }

        Swal.fire({
            title: "¿Estás seguro de querer eliminar las asignaturas seleccionadas?",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Aceptar",
            cancelButtonText: "Cancelar",
        }).then((result) => {
            if (result.isConfirmed) {
                celdasSeleccionadas.forEach((celda) => {
                    celda.style.backgroundColor = "";
                    celda.textContent = "";
                    celda.style.cursor = "default";
                    eliminarHorarioDeBD(celda.dataset.dia, celda.dataset.hora);
                });
                celdasSeleccionadas = [];
                Swal.fire(
                    "Eliminadas",
                    "Las asignaturas han sido eliminadas.",
                    "success"
                );
            }
        });
    });

function eliminarHorarioDeBD(dia, hora) {
    $.ajax({
        url: "eliminar_horario.php",
        type: "POST",
        data: {
            dia: dia,
            hora: hora,
        },
        success: function(response) {
            console.log("Horario eliminado de la base de datos.");
        },
        error: function(xhr, status, error) {
            console.error("Error al eliminar el horario de la base de datos:", error);
        },
    });
}

document.addEventListener("DOMContentLoaded", function() {
    cargarHorarios();
    cargarVersiones();
});