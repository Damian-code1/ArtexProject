<?php
if (isset($_POST['nombre'])) {
    $nombre = $_POST['nombre'];

    $conn = new mysqli('localhost', 'root', '', 'metrus');
    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    $stmt = $conn->prepare("DELETE FROM Asignaturas WHERE nombre = ?");
    $stmt->bind_param("s", $nombre);
    $stmt->execute();
    $stmt->close();
    $conn->close();

    echo "Materia eliminada exitosamente.";
} else {
    http_response_code(400);
    echo "Nombre de materia no proporcionado.";
}
?>