<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calendario Docente - Metrus</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <style>
        .btn {
            background-color: #4b0082;
            color: white;
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            margin-top: 20px;
        }

        .btn:hover {
            background-color: #32006d;
        }
    </style>
</head>

<body>
    <div class="header">
        <a href="inicio.php" class="logo">metrus.</a>
        <div class="header-right">
            <a class="active" href="inicio.php">Inicio</a>
            <a href="login.php" id="login-link">Iniciar Sesión</a>
            <a href="registrarse.php">Registrarse</a>
            <a href="admin_materias.php">Administrar Materias</a>
        </div>
    </div>

    <div class="main-content">
        <header class="header">
            <h1>Calendario de Horarios - Docente</h1>
        </header>

        <main>
            <table class="horario">
                <thead>
                    <tr>
                        <th>Horas</th>
                        <th>(L) Lunes</th>
                        <th>(M) Martes</th>
                        <th>(X) Miércoles</th>
                        <th>(J) Jueves</th>
                        <th>(V) Viernes</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>07:30 - 08:15</td>
                        <td data-dia="lunes" data-hora="07:30-08:15"></td>
                        <td data-dia="martes" data-hora="07:30-08:15"></td>
                        <td data-dia="miercoles" data-hora="07:30-08:15"></td>
                        <td data-dia="jueves" data-hora="07:30-08:15"></td>
                        <td data-dia="viernes" data-hora="07:30-08:15"></td>
                    </tr>
                    <tr>
                        <td>08:15 - 08:55</td>
                        <td data-dia="lunes" data-hora="08:15-08:55"></td>
                        <td data-dia="martes" data-hora="08:15-08:55"></td>
                        <td data-dia="miercoles" data-hora="08:15-08:55"></td>
                        <td data-dia="jueves" data-hora="08:15-08:55"></td>
                        <td data-dia="viernes" data-hora="08:15-08:55"></td>
                    </tr>
                    <tr>
                        <td>09:00 - 09:45</td>
                        <td data-dia="lunes" data-hora="09:00-09:45"></td>
                        <td data-dia="martes" data-hora="09:00-09:45"></td>
                        <td data-dia="miercoles" data-hora="09:00-09:45"></td>
                        <td data-dia="jueves" data-hora="09:00-09:45"></td>
                        <td data-dia="viernes" data-hora="09:00-09:45"></td>
                    </tr>
                    <tr>
                        <td>09:50 - 10:35</td>
                        <td data-dia="lunes" data-hora="09:50-10:35"></td>
                        <td data-dia="martes" data-hora="09:50-10:35"></td>
                        <td data-dia="miercoles" data-hora="09:50-10:35"></td>
                        <td data-dia="jueves" data-hora="09:50-10:35"></td>
                        <td data-dia="viernes" data-hora="09:50-10:35"></td>
                    </tr>
                    <tr>
                        <td>10:50 - 11:35</td>
                        <td data-dia="lunes" data-hora="10:50-11:35"></td>
                        <td data-dia="martes" data-hora="10:50-11:35"></td>
                        <td data-dia="miercoles" data-hora="10:50-11:35"></td>
                        <td data-dia="jueves" data-hora="10:50-11:35"></td>
                        <td data-dia="viernes" data-hora="10:50-11:35"></td>
                    </tr>
                    <tr>
                        <td>11:35 - 12:15</td>
                        <td data-dia="lunes" data-hora="11:35-12:15"></td>
                        <td data-dia="martes" data-hora="11:35-12:15"></td>
                        <td data-dia="miercoles" data-hora="11:35-12:15"></td>
                        <td data-dia="jueves" data-hora="11:35-12:15"></td>
                        <td data-dia="viernes" data-hora="11:35-12:15"></td>
                    </tr>
                    <tr>
                        <td>12:20 - 13:05</td>
                        <td data-dia="lunes" data-hora="12:20-13:05"></td>
                        <td data-dia="martes" data-hora="12:20-13:05"></td>
                        <td data-dia="miercoles" data-hora="12:20-13:05"></td>
                        <td data-dia="jueves" data-hora="12:20-13:05"></td>
                        <td data-dia="viernes" data-hora="12:20-13:05"></td>
                    </tr>
                    <tr>
                        <td>13:10 - 13:55</td>
                        <td data-dia="lunes" data-hora="13:10-13:55"></td>
                        <td data-dia="martes" data-hora="13:10-13:55"></td>
                        <td data-dia="miercoles" data-hora="13:10-13:55"></td>
                        <td data-dia="jueves" data-hora="13:10-13:55"></td>
                        <td data-dia="viernes" data-hora="13:10-13:55"></td>
                    </tr>
                    <tr>
                        <td>14:30 - 15:15</td>
                        <td data-dia="lunes" data-hora="14:30-15:15"></td>
                        <td data-dia="martes" data-hora="14:30-15:15"></td>
                        <td data-dia="miercoles" data-hora="14:30-15:15"></td>
                        <td data-dia="jueves" data-hora="14:30-15:15"></td>
                        <td data-dia="viernes" data-hora="14:30-15:15"></td>
                    </tr>
                </tbody>
            </table>
        </main>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            const urlParams = new URLSearchParams(window.location.search);
            const cod_docente = urlParams.get('cod_docente');

            $.ajax({
                url: 'cargar_horarios_docente.php',
                type: 'POST',
                data: { cod_docente: cod_docente },
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success') {
                        const horarios = response.horarios;
                        horarios.forEach(horario => {
                            const celda = $(`td[data-dia="${horario.dia}"][data-hora="${horario.hora}"]`);
                            if (celda.length) {
                                celda.css('background-color', horario.color);
                                celda.text(horario.curso);
                            }
                        });
                    } else {
                        Swal.fire({
                            title: 'Error',
                            text: response.message,
                            icon: 'error',
                            confirmButtonText: 'Aceptar'
                        });
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error al cargar los horarios:', error);
                }
            });
        });
    </script>
</body>

</html>