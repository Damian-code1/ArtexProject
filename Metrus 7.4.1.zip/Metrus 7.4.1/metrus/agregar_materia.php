<?php

if (isset($_POST['nombre']) && isset($_POST['descripcion']) && isset($_POST['orientacion']) && isset($_POST['color'])) {
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $orientacion = $_POST['orientacion'];
    $color = $_POST['color'];

    $conn = new mysqli('localhost', 'root', '', 'metrus');
    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    // Valida el color HEX
    if (!preg_match('/^#[a-fA-F0-9]{6}$/', $color)) {
        http_response_code(400);
        echo "El color debe ser un código HEX válido.";
    } else {
        $stmt = $conn->prepare("SELECT COUNT(*) FROM Asignaturas WHERE nombre = ?");
        $stmt->bind_param("s", $nombre);
        $stmt->execute();
        $stmt->bind_result($count);
        $stmt->fetch();
        $stmt->close();

        if ($count > 0) {
            http_response_code(400);
            echo "El nombre de la materia ya existe. Por favor, elija otro nombre.";
        } else {
            $stmt = $conn->prepare("SELECT COUNT(*) FROM Asignaturas WHERE color = ?");
            $stmt->bind_param("s", $color);
            $stmt->execute();
            $stmt->bind_result($count);
            $stmt->fetch();
            $stmt->close();

            if ($count > 0) {
                http_response_code(400);
                echo "El color ya está en uso. Por favor, elija otro color.";
            } else {
                $stmt = $conn->prepare("INSERT INTO Asignaturas (nombre, descripcion, orientacion, color) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("ssss", $nombre, $descripcion, $orientacion, $color);
                $stmt->execute();
                $stmt->close();
                echo "Materia agregada exitosamente.";
            }
        }
    }

    $conn->close();
} else {
    http_response_code(400);
    echo "Datos incompletos.";
}
?>