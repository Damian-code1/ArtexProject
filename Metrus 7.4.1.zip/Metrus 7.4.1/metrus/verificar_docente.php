<?php
require_once 'conexion.php';

header('Content-Type: application/json');

$conn = Conectar::conexion();

if (isset($_POST['cod_docente'])) {
    $cod_docente = $conn->real_escape_string($_POST['cod_docente']);

    $sql_check = "SELECT * FROM Docentes WHERE cod_docente='$cod_docente'";
    $result = $conn->query($sql_check);

    if ($result->num_rows > 0) {
        echo json_encode(["status" => "success", "message" => "Código de docente verificado."]);
    } else {
        echo json_encode(["status" => "error", "message" => "Código de docente incorrecto."]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "No se recibió el código de docente."]);
}

$conn->close();
?>