<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrarse</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>
    <img src="img/perfil-violeta.png" alt="Perfil" class="perfil-v">
    <img src="img/Metrus.png" alt="Perfil" class="logoC">
    <img src="img/lineas.png" alt="Decoracion" class="lineas">

    <h1 class="preg">Registrarse</h1>

    <form id="registerForm" action="registrar.php" method="post">
        <input type="text" id="ci" name="ci" class="R1 formato-form" placeholder="C.I" required>
        <input type="email" id="mail" name="mail" class="R2 formato-form" placeholder="Mail" required>
        <input type="password" id="password" name="password" class="R3 formato-form" placeholder="Contraseña" required>
        <button type="submit" class="formato-L rg-log">Registrar</button>
    </form>

    <script>
    $(document).ready(function() {
        $('#registerForm').submit(function(event) {
            event.preventDefault();

            const ci = $('#ci');
            const password = $('#password');
            let valid = true;

            if (ci.val().length !== 8) {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'La C.I debe tener 8 caracteres.'
                }).then(() => {
                    $('#ci').focus();
                });
                valid = false;
            }

            if (password.val().length <= 4) {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'La contraseña debe tener más de 4 caracteres.'
                }).then(() => {
                    $('#password').focus();
                });
                valid = false;
            }

            if (valid) {
                $.ajax({
                    url: 'registrar.php',
                    type: 'POST',
                    data: $('#registerForm').serialize(),
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === 'error') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: response.message
                            }).then(() => {
                                $('#ci').focus();
                            });
                            $('#registerForm')[0].reset();
                        } else {
                            Swal.fire({
                                icon: 'success',
                                title: 'Éxito',
                                text: response.message
                            }).then((result) => {
                                if (result.isConfirmed) {
                                    window.location.href = 'login.php';
                                }
                            });
                        }
                    },
                    error: function() {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Error en la solicitud.'
                        }).then(() => {
                            $('#ci').focus();
                        });
                    }
                });
            }
        });

        $(document).on('keydown', function(e) {
            if (e.key === 'Enter') {
                const activeElement = document.activeElement;
                if (activeElement.tagName === 'BUTTON' || activeElement.tagName === 'INPUT') {
                    e.preventDefault();
                    $('#registerForm').submit();
                }
            }
        });
    });
    </script>
</body>

</html>