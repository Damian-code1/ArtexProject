<?php
$conn = new mysqli('localhost', 'root', '', 'metrus');
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$version = $_GET['version'];
$result = $conn->query("SELECT nombre, color FROM Asignaturas WHERE version = $version");

$asignaturas = [];
while ($row = $result->fetch_assoc()) {
    $asignaturas[] = $row;
}

echo json_encode($asignaturas);
?>