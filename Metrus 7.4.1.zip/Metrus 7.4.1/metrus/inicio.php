<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Metrus</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
    body {
        background-color: #000;
        color: #fff;
        font-family: 'Arial', sans-serif;
        margin: 0;
        padding: 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 100vh;
        overflow: hidden;
    }

    .logo {
        width: 200px;
        margin-bottom: 20px;
    }

    .content {
        text-align: center;
        animation: fadeIn 2s;
    }

    .content h1 {
        font-size: 48px;
        margin-bottom: 20px;
        animation: bounceInDown 2s;
    }

    .content p {
        font-size: 18px;
        margin-bottom: 40px;
        animation: fadeInUp 2s;
    }

    .btn-custom {
        background-color: #6A329F;
        color: #fff;
        border: none;
        padding: 10px 20px;
        font-size: 18px;
        border-radius: 5px;
        transition: background-color 0.3s ease;
        margin-bottom: 20px;
    }

    .btn-custom:hover {
        background-color: #9C4FE5;
    }

    .footer {
        position: absolute;
        bottom: 20px;
        text-align: center;
        width: 100%;
        animation: fadeInUp 2s;
    }

    .footer p {
        margin: 0;
        font-size: 14px;
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
        }

        to {
            opacity: 1;
        }
    }

    @keyframes bounceInDown {
        0%,
        60%,
        75%,
        90%,
        100% {
            animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
        }

        0% {
            opacity: 0;
            transform: translateY(-3000px);
        }

        60% {
            opacity: 1;
            transform: translateY(25px);
        }

        75% {
            transform: translateY(-10px);
        }

        90% {
            transform: translateY(5px);
        }

        100% {
            transform: translateY(0);
        }
    }

    @keyframes fadeInUp {
        from {
            transform: translate3d(0, 40px, 0);
            opacity: 0;
        }

        to {
            transform: translate3d(0, 0, 0);
            opacity: 1;
        }
    }
    </style>
</head>

<body>
    <div class="content">
        <img src="img/Metrus.png" alt="Logo Metrus" class="logo animate__animated animate__fadeIn">
        <h1 class="animate__animated animate__bounceInDown">Bienvenido a Metrus</h1>
        <p class="animate__animated animate__fadeInUp">La mejor plataforma para la gestión de horarios y cursos.</p>
        <a href="login.php" class="btn btn-custom animate__animated animate__fadeInUp">Iniciar Sesión</a> <br>
        <a href="registrarse.php" class="btn btn-custom animate__animated animate__fadeInUp" style="animation-delay: 0.5s;">Registrarse</a>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>